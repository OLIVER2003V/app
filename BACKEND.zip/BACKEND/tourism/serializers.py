from rest_framework import serializers
from .models import Place, Media, Event, Post, Review, ContactInfo

class MediaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Media
        fields = ["id", "image", "caption", "created_at"]

class PlaceSerializer(serializers.ModelSerializer):
    media = MediaSerializer(many=True, read_only=True)
    avg_rating = serializers.SerializerMethodField()

    class Meta:
        model = Place
        fields = [
            "id", "name", "slug", "category", "description", "address",
            "lat", "lng", "is_active", "media", "avg_rating", "created_at"
        ]

    def get_avg_rating(self, obj):
        # Más robusto: evita cargar todo a memoria
        vals = obj.reviews.filter(is_approved=True).values_list("rating", flat=True)
        vals = list(vals)
        if not vals:
            return None
        return round(sum(vals) / len(vals), 2)

class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = "__all__"

class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = "__all__"
        read_only_fields = ["created_by", "created_at"]

    def create(self, validated_data):
        request = self.context.get("request")
        if request and request.user and request.user.is_authenticated:
            validated_data["created_by"] = request.user
        return super().create(validated_data)

class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ["id", "place", "rating", "comment", "author_name", "is_approved", "created_at"]
        read_only_fields = ["is_approved"]

class ContactInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactInfo
        fields = "__all__"
