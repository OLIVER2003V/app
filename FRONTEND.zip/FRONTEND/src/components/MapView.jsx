import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

const icon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41], iconAnchor: [12, 41]
});

export default function MapView({ points = [], center = [-17.78, -63.18], zoom = 12 }) {
  return (
    <MapContainer center={center} zoom={zoom} style={{ height: 420, width: "100%", borderRadius: 12 }}>
      <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {points.map(p => (
        <Marker key={p.id} position={[p.lat, p.lng]} icon={icon}>
          <Popup><b>{p.name}</b><br />{p.category}</Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
