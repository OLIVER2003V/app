import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@context/AuthContext";
import ProtectedRoute from "@components/ProtectedRoute";
import Layout from "@components/Layout";

import Login from "@pages/Login";
import Places from "@pages/Places";
import PlaceDetail from "@pages/PlaceDetail";
import Events from "@pages/Events";
import Contact from "@pages/Contact";
import Dashboard from "@pages/Dashboard";
import Home from "./pages/Home";
// Si tu archivo es src/pages/CreatePost.jsx usa esta línea:
import CreatePost from "./pages/CreatePost";
import PostsAdmin from "./pages/PostsAdmin";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Rutas que comparten el mismo layout (Navbar fijo) */}
          <Route element={<Layout />}>
            {/* públicas */}
            <Route path="/" element={<Home />} />
            <Route path="/places" element={<Places />} />
            <Route path="/places/:slug" element={<PlaceDetail />} />
            <Route path="/events" element={<Events />} />
            <Route path="/contact" element={<Contact />} />

            {/* privadas (anidar con ProtectedRoute como “gate”) */}
            <Route
              path="/admin/posts/new"
              element={
                <ProtectedRoute roles={["admin", "editor"]}>
                  <CreatePost />
                </ProtectedRoute>
              }
            />
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
          </Route> 
          <Route
            path="/admin/posts"
            element={
                <ProtectedRoute roles={["admin", "editor"]}>
                <PostsAdmin />
                </ProtectedRoute>
            }
            />


          {/* login puede ir fuera del layout si no quieres mostrar el Navbar */}
          <Route path="/login" element={<Login />} />

          {/* 404 opcional */}
          <Route path="*" element={<div style={{ padding: 20 }}>Página no encontrada</div>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
