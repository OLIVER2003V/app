import React from "react";
export default function UserDashboard() {
  return (
    <div style={{padding:20}}>
      <h1>Mi Panel</h1>
      <ul>
        <li>Favoritos / Reservas</li>
        <li>Perfil</li>
      </ul>
    </div>
  );
}
