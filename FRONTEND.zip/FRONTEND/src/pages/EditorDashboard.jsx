import React from "react";
export default function EditorDashboard() {
  return (
    <div style={{padding:20}}>
      <h1>Panel Editor</h1>
      <ul>
        <li>Mis lugares/eventos</li>
        <li>Borradores y publicaciones</li>
      </ul>
    </div>
  );
}
