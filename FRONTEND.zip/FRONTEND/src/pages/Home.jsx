import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./home.css";
import api from "@lib/api";

export default function Home() {
  const [posts, setPosts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Intenta traer destacadas y limitar; si el backend aún no lo soporta,
    // hacemos fallback trayendo todo y cortando en el cliente.
    api
      .get("/posts/", { params: { featured: 1, limit: 6 } })
      .then(({ data }) => {
        const arr = Array.isArray(data) ? data : [];
        setPosts(arr.length ? arr : arr.slice(0, 6));
      })
      .catch(() => {
        api.get("/posts/").then(({ data }) => {
          const arr = Array.isArray(data) ? data : [];
          setPosts(arr.slice(0, 6));
        });
      });
  }, []);

  const openPost = (p) => {
    if (p.cta_url) {
      window.open(p.cta_url, "_blank", "noopener,noreferrer");
      return;
    }
    if (p.place?.slug) {
      navigate(`/places/${p.place.slug}`);
      return;
    }
    navigate(`/posts/${p.id}`);
  };

  return (
    <div className="home">
      {/* HERO */}
      <section className="hero">
        <div className="hero__overlay" />
        <div className="hero__content">
          <h1>Jardín de las Delicias</h1>
          <p>Un paraíso por descubrir 🌿 Cascadas, senderos y tours guiados.</p>
          <div className="hero__cta">
            <Link to="/places" className="btn btn--primary">Ver lugares</Link>
            <Link to="/events" className="btn btn--ghost">Tours & Eventos</Link>
          </div>

          {/* PUBLICACIONES DESTACADAS */}
          {posts.length > 0 && (
            <div className="hero__posts">
              {posts.map((p) => (
                <button key={p.id} className="postCard" onClick={() => openPost(p)} title={p.title}>
                  <div className="postCard__media">
                    {p.cover ? (
                      <img src={p.cover} alt={p.title} />
                    ) : (
                      <div className="postCard__ph">Sin imagen</div>
                    )}
                  </div>
                  <div className="postCard__body">
                    <h3 className="postCard__title">{p.title}</h3>
                    {p.place?.name && <span className="postCard__place">📍 {p.place.name}</span>}
                    {p.cta_label && <span className="postCard__cta">{p.cta_label}</span>}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ACCIONES RÁPIDAS */}
      <section className="quick">
        <div className="quick__grid">
          <a className="card" href="https://maps.google.com/?q=Jardín+de+las+Delicias+Santa+Cruz" target="_blank" rel="noreferrer">
            <span className="card__icon">🧭</span>
            <h3>¿Cómo llegar?</h3>
            <p>Indicaciones y ruta desde tu ubicación.</p>
          </a>

          <a className="card" href="https://www.google.com/maps/dir/?api=1&destination=Jardín+de+las+Delicias+Santa+Cruz" target="_blank" rel="noreferrer">
            <span className="card__icon">🗺️</span>
            <h3>Ruta trazada</h3>
            <p>Abre Google Maps con el destino listo.</p>
          </a>

          <a className="card" href="#mapa">
            <span className="card__icon">📍</span>
            <h3>Ubicación</h3>
            <p>Ver el mapa y zonas cercanas.</p>
          </a>

          <Link className="card" to="/contact">
            <span className="card__icon">ℹ️</span>
            <h3>Información</h3>
            <p>Horarios, tarifas y contacto.</p>
          </Link>

          <a className="card" href="https://wa.me/59170000000?text=Hola%20quiero%20información%20del%20Jardín%20de%20las%20Delicias" target="_blank" rel="noreferrer">
            <span className="card__icon">💬</span>
            <h3>WhatsApp</h3>
            <p>Atención turística directa.</p>
          </a>

          <Link className="card" to="/places">
            <span className="card__icon">🏕️</span>
            <h3>Cabañas</h3>
            <p>Alojamientos y servicios disponibles.</p>
          </Link>
        </div>
      </section>

      {/* TARIFAS / INFO DESTACADA */}
      <section className="pricing">
        <div className="pricing__box">
          <h2>Tarifas</h2>
          <div className="pricing__rows">
            <div className="pricing__row">
              <span>Ingreso al Jardín de las Delicias</span>
              <span className="badge">10 Bs</span>
            </div>
            <p className="pricing__desc">
              Uso del área de parque, guías, salvavidas en la cascada, baños y mantenimiento de senderos.
            </p>
            <div className="pricing__row">
              <span>Ingreso al Parque Nacional Amboró</span>
              <span className="badge badge--alt">20 Bs</span>
            </div>
            <p className="pricing__desc">
              Recaudación a través del sistema SISCO del SERNAP para áreas protegidas de Bolivia.
            </p>
          </div>
        </div>
      </section>

      {/* MINI GALERÍA */}
      <section className="gallery">
        <h2>Conoce el lugar</h2>
        <div className="gallery__rail">
          <img src="/gal-1.jpg" alt="Cascada" />
          <img src="/gal-2.jpg" alt="Sendero" />
          <img src="/gal-3.jpg" alt="Pozas" />
          <img src="/gal-4.jpg" alt="Mirador" />
        </div>
      </section>

      {/* MAPA (teaser) */}
      <section id="mapa" className="map">
        <h2>Ubicación</h2>
        <div className="map__frame">
          <iframe
            title="Mapa Jardín de las Delicias"
            src="https://www.openstreetmap.org/export/embed.html?bbox=-63.276%2C-17.95%2C-63.06%2C-17.68&layer=mapnik&marker=-17.78%2C-63.18"
            style={{ border: 0 }}
            loading="lazy"
          />
        </div>
        <div className="map__links">
          <a href="https://www.openstreetmap.org/?mlat=-17.78&mlon=-63.18#map=11/-17.78/-63.18" target="_blank" rel="noreferrer">
            Abrir en OpenStreetMap
          </a>
          <a href="https://maps.google.com/?q=Jardín+de+las+Delicias+Santa+Cruz" target="_blank" rel="noreferrer">
            Abrir en Google Maps
          </a>
        </div>
      </section>
    </div>
  );
}
