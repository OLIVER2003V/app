import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../lib/api";
import MapView from "../components/MapView";

export default function PlaceDetail() {
  const { slug } = useParams();
  const [place, setPlace] = useState(null);
  const [review, setReview] = useState({ rating: 5, comment: "", author_name: "" });

  useEffect(() => {
    api.get(`/places/${slug}/`).then(({ data }) => setPlace(data));
  }, [slug]);

  async function sendReview(e) {
    e.preventDefault();
    await api.post("/reviews/", { ...review, place: place.id });
    setReview({ rating: 5, comment: "", author_name: "" });
    alert("¡Gracias por tu opinión!");
  }

  if (!place) return <div style={{padding:20}}>Cargando…</div>;

  const points = place.lat && place.lng
    ? [{ id: place.id, name: place.name, lat: Number(place.lat), lng: Number(place.lng), category: place.category }]
    : [];

  return (
    <div style={{ padding: 20 }}>
      <h2>{place.name}</h2>
      <p>{place.description}</p>

      {points.length ? <MapView points={points} center={[points[0].lat, points[0].lng]} zoom={14} /> : null}

      <h3>Deja tu opinión</h3>
      <form onSubmit={sendReview}>
        <label>Calificación (1-5)</label>
        <input type="number" min="1" max="5" value={review.rating}
               onChange={(e)=>setReview(r=>({...r, rating:Number(e.target.value)}))} />
        <label>Comentario</label>
        <textarea value={review.comment}
                  onChange={(e)=>setReview(r=>({...r, comment:e.target.value}))}/>
        <label>Tu nombre</label>
        <input value={review.author_name}
               onChange={(e)=>setReview(r=>({...r, author_name:e.target.value}))}/>
        <button type="submit">Enviar</button>
      </form>

      <style>{`
        form { max-width: 520px }
        input, textarea { display:block; width:100%; margin:8px 0; padding:10px; }
        button { margin-top:8px; padding:10px 14px; }
      `}</style>
    </div>
  );
}
