import React, { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import api from "../lib/api";
import MapView from "../components/MapView";

export default function Places() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);
  const [sp] = useSearchParams();
  const q = (sp.get("q") || "").trim();

  useEffect(() => {
    let cancel = false;
    setLoading(true);
    setErr(null);

    // Si tu backend acepta ?q=, pásalo como query param
    api
      .get("/places/", { params: q ? { q } : {} })
      .then(({ data }) => {
        if (!cancel) setData(Array.isArray(data) ? data : []);
      })
      .catch((e) => !cancel && setErr(e?.message || "Error al cargar lugares"))
      .finally(() => !cancel && setLoading(false));

    return () => { cancel = true; };
  }, [q]);

  // Fallback: si el backend aún no filtra por q, filtra en cliente
  const filtered = useMemo(() => {
    if (!q) return data;
    const term = q.toLowerCase();
    return data.filter((p) =>
      [p.name, p.category, p.description]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(term))
    );
  }, [data, q]);

  const points = useMemo(() => {
    return filtered
      .filter((p) => p.lat && p.lng)
      .map((p) => ({
        id: p.id,
        name: p.name,
        lat: Number(p.lat),
        lng: Number(p.lng),
        category: p.category
      }));
  }, [filtered]);

  return (
    <div style={{ padding: 20 }}>
      <h2 style={{ marginBottom: 8 }}>Lugares</h2>

      {/* estado */}
      {loading && <div>Cargando…</div>}
      {err && <div style={{ color: "salmon" }}>{err}</div>}

      {/* resumen resultados */}
      {!loading && !err && (
        <div style={{ color: "#9aa0a6", marginBottom: 8 }}>
          {q ? (
            <>Resultados para <b>“{q}”</b>: {filtered.length}</>
          ) : (
            <>Total: {filtered.length}</>
          )}
        </div>
      )}

      {/* mapa */}
      {!loading && !err && <MapView points={points} />}

      {/* lista */}
      <ul style={{ marginTop: 16 }}>
        {!loading && !err && filtered.length === 0 && (
          <li>No se encontraron lugares.</li>
        )}
        {filtered.map((p) => (
          <li key={p.id}>
            <Link to={`/places/${p.slug}`}>{p.name}</Link>
            {" — "}
            {p.category}
            {p.avg_rating ? ` ⭐ ${p.avg_rating}` : ""}
          </li>
        ))}
      </ul>
    </div>
  );
}
