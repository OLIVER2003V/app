import { useEffect, useState } from "react";
import api from "../lib/api";

export default function Events() {
  const [events, setEvents] = useState([]);
  useEffect(() => { api.get("/events/").then(({ data }) => setEvents(data)); }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>Eventos</h2>
      <ul>
        {events.map(e => (
          <li key={e.id}>
            <b>{e.title}</b> — {new Date(e.start_date).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
