import { useEffect, useState } from "react";
import api from "../lib/api";

export default function Contact() {
  const [items, setItems] = useState([]);
  useEffect(() => { api.get("/contact/").then(({ data }) => setItems(data)); }, []);

  return (
    <div style={{ padding: 20 }}>
      <h2>Contacto</h2>
      {items.length === 0 ? <p>Sin datos</p> : items.map((c) => (
        <div key={c.id} style={{ marginBottom: 12 }}>
          <div><b>Email:</b> {c.email}</div>
          <div><b>Tel:</b> {c.phone} / <b>WhatsApp:</b> {c.whatsapp}</div>
          <div><b>Dirección:</b> {c.address}</div>
          {c.facebook && <div><b>Facebook:</b> <a href={c.facebook} target="_blank">{c.facebook}</a></div>}
          {c.instagram && <div><b>Instagram:</b> <a href={c.instagram} target="_blank">{c.instagram}</a></div>}
        </div>
      ))}
    </div>
  );
}
