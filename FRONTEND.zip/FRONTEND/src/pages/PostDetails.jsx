import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@lib/api";

export default function PostDetail() {
  const { id } = useParams();
  const [post, setPost] = useState(null);

  useEffect(() => {
    api.get(`/posts/${id}/`).then(({ data }) => setPost(data));
  }, [id]);

  if (!post) return <div style={{ padding: 20 }}>Cargando…</div>;

  return (
    <div style={{ padding: 20, maxWidth: 900, margin: "0 auto" }}>
      {post.cover && (
        <img
          src={post.cover}
          alt={post.title}
          style={{ width: "100%", borderRadius: 12, marginBottom: 16 }}
        />
      )}
      <h1>{post.title}</h1>
      <div style={{ color: "#9aa0a6", marginBottom: 12 }}>
        {post.created_at && new Date(post.created_at).toLocaleDateString()}
        {post.place?.name && <> · <Link to={`/places/${post.place.slug}`}>{post.place.name}</Link></>}
      </div>
      <article style={{ lineHeight: 1.7 }}>{post.body}</article>
    </div>
  );
}
